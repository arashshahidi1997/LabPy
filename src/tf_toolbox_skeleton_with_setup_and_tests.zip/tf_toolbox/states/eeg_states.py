"""EEG state classification."""
def CheckEegStates(*args, **kwargs):
    raise NotImplementedError

def CheckEegStates_OLD(*args, **kwargs):
    raise NotImplementedError

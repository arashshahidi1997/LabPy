"""Spike-field connectivity and helpers."""
def JPSTH(*args, **kwargs):
    raise NotImplementedError

def TrigRasters(*args, **kwargs):
    raise NotImplementedError

def PowerPhasePairs(*args, **kwargs):
    raise NotImplementedError

def FiringRate(*args, **kwargs):
    raise NotImplementedError

def UnitGammaLocking(*args, **kwargs):
    raise NotImplementedError

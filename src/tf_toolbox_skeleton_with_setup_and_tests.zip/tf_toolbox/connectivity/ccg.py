"""Cross-correlograms and related rasters."""
def CCG(*args, **kwargs):
    raise NotImplementedError

def Trains2CCG(*args, **kwargs):
    raise NotImplementedError

def CCG_part(*args, **kwargs):
    raise NotImplementedError

def CatTrains(*args, **kwargs):
    raise NotImplementedError

"""Time–frequency coherence (coherograms)."""
def TrigCoherogram(*args, **kwargs):
    raise NotImplementedError

def mtchglong(*args, **kwargs):
    raise NotImplementedError

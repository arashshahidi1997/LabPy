# Matplotlib helpers for spectral plots

# Matplotlib helpers for connectivity plots

"""test_connectivity module."""


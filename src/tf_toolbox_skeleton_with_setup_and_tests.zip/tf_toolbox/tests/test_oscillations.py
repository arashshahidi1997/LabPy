"""test_oscillations module."""


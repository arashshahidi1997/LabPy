"""Gamma-related event detection and analysis."""
def Gamma_EcHpc_G(*args, **kwargs):
    raise NotImplementedError

def Gamma_EcHpc_GM(*args, **kwargs):
    raise NotImplementedError

def Gamma_EcHpc_GU(*args, **kwargs):
    raise NotImplementedError

def Gamma_EcHpc_GMU(*args, **kwargs):
    raise NotImplementedError

def DetectOscillations(*args, **kwargs):
    raise NotImplementedError

def DetectRipples(*args, **kwargs):
    raise NotImplementedError

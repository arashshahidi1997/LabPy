# TF Toolbox (Python)

A Pythonic but faithful reimplementation of the MATLAB TF directory for neural time–frequency analysis.

See `tf_toolbox/` for subpackages and placeholder functions to implement. 

## Testing

Run the test suite locally:

```bash
pip install -e .
pip install pytest
pytest -q
```

GitHub Actions workflow is included at `.github/workflows/ci.yml` and runs on Python 3.9–3.12.

"""Theta-related utilities."""
def ThetaParams(*args, **kwargs):
    raise NotImplementedError

def ThGamMod(*args, **kwargs):
    raise NotImplementedError

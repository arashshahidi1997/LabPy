"""Harmonic analysis helpers."""
def Harmonix(*args, **kwargs):
    raise NotImplementedError

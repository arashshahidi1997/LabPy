"""Analytic signal / Hilbert utilities."""
def HilbertPhase(*args, **kwargs):
    raise NotImplementedError

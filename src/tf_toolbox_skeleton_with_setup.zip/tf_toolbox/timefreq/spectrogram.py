"""Time–frequency power (spectrograms)."""
def TrigSpecgram(*args, **kwargs):
    raise NotImplementedError

def mtcsglong(*args, **kwargs):
    raise NotImplementedError

def mtcsglongEd(*args, **kwargs):
    raise NotImplementedError

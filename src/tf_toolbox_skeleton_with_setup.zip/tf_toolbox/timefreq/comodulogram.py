"""Cross-frequency coupling."""
def Comodugram(*args, **kwargs):
    raise NotImplementedError

def ComodugramRank(*args, **kwargs):
    raise NotImplementedError

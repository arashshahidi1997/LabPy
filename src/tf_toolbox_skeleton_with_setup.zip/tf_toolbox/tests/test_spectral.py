"""test_spectral module."""


"""Significance testing for CCGs."""
def CCGSignif(*args, **kwargs):
    raise NotImplementedError

def CCGSignifConv(*args, **kwargs):
    raise NotImplementedError
